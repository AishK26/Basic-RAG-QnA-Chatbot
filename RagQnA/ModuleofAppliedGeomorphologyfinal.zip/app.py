import streamlit as st
from backend import run_query   # import function from AdvRag.ipynb

st.set_page_config(page_title="PDF Q&A Bot", page_icon="📘", layout="centered")

st.title("📘 PDF Q&A Bot")
st.write("Ask questions about your PDF using HuggingFace embeddings + Flan-T5.")

# Input box
question = st.text_input("Enter your question:")

# Button
if st.button("Ask"):
    if question.strip() == "":
        st.warning("⚠️ Please enter a question.")
    else:
        with st.spinner("Thinking..."):
            answer = run_query(question)  # call backend
        st.success("Answer:")
        st.write(answer)
